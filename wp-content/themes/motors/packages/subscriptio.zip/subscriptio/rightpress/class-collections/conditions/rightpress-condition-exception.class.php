<?php

// Exit if accessed directly
defined('ABSPATH') || exit;

/**
 * RightPress Condition Exception Class
 *
 * @class RightPress_Condition_Exception
 * @package RightPress
 * @author RightPress
 */
class RightPress_Condition_Exception extends RightPress_Exception
{



}

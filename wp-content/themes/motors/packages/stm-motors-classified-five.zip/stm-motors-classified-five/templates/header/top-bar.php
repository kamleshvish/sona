<?php
$bgColor = get_theme_mod('top_bar_bg_color', '');
$top_bar_address = get_theme_mod('top_bar_address', '');
$header_address_url = get_theme_mod('header_address_url', '');
?>

<div class="top-bar-wrap">
	<div class="container">
		<div class="stm-c-f-top-bar">
			<?php stm_c_f_load_template('header/parts/lang-switcher'); ?>
            <?php if(!empty($top_bar_address)) : ?>
                <div class="stm-top-address-wrap">
                    <span id="top-bar-address" class="<?php if( !empty($header_address_url) ) echo 'fancy-iframe'; ?>" data-iframe="true" data-src="<?php echo esc_url($header_address_url); ?>">
                        <i class="fa fa-map-marker"></i> <?php stm_dynamic_string_translation_e('Top Bar Address', $top_bar_address ); ?>
                    </span>
                </div>
            <?php endif; ?>
            <div class="pull-right">
                <?php stm_c_f_load_template('header/parts/socials'); ?>
                <?php if(!is_user_logged_in()) stm_c_f_load_template('header/parts/login-reg-links'); ?>
            </div>
		</div>
	</div>
</div>
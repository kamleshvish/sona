<?php
$date = get_the_date('d - M');
$dateParse = explode(' - ', $date);
?>
<div class="recent-post-item">
	<div class="img">
		<?php the_post_thumbnail('full'); ?>
		<div class="date">
			<span class="day heading-font"><?php echo esc_html($dateParse[0]);?></span>
            <span class="month heading-font"><?php echo esc_html($dateParse[1]);?></span>
		</div>
	</div>
	<h4><?php the_title(); ?></h4>
	<div class="excerpt">
		<?php the_excerpt(); ?>
	</div>
</div>

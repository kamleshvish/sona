<?php
$compare_page = \uListing\Classes\StmListingSettings::getPages("compare_page");
?>
<hr>
<h3><?php _e("Compare","ulisting");?></h3>
<div class="p-t-30">
	<div class="form-group">
		<div class="stm-row">
			<div class="stm-col-3">
				<label> <?php _e("Compare page","ulisting");?></label>
			</div>
			<div class="stm-col-5">
				<select name="StmListingsSettings[pages][compare_page]" class="_select2">
					<option value="0">-- No page --</option>
					<?php foreach (get_pages() as $page):?>
						<option  <?php echo ($compare_page == $page->ID) ?'selected':''?> value="<?php echo $page->ID?>">
							<?php echo $page->post_title?>
						</option>
					<?php endforeach;?>
				</select>
			</div>
		</div>
	</div>
</div>

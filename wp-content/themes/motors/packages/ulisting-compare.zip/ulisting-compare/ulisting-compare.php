<?php
/**
 * Plugin Name: uListing - Compare
 * Plugin URI: https://ulisting.stylemixthemes.com/
 * Description: uListing Compare - Listing Compare Plugin.
 * Author: StylemixThemes
 * Author URI: https://stylemixthemes.com/
 * Text Domain: ulisting-compare
 * Version: 1.1.2
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'ULISTING_LISTING_COMPARE_VERSION', '1.1.1' );
define( 'ULISTING_LISTING_COMPARE_PATH', dirname( __FILE__ ) );
define( 'ULISTING_LISTING_COMPARE_FILE', __FILE__ );
define( 'ULISTING_LISTING_COMPARE_URL', plugins_url( '', __FILE__ ) );
require_once __DIR__ . '/includes/autoload.php';
register_activation_hook( __FILE__,  'uListing_listing_compare_plugin_activation');
register_deactivation_hook( __FILE__, 'uListing_listing_compare_plugin_deactivation');
register_uninstall_hook( __FILE__, 'uListing_listing-compare_plugin_uninstall');

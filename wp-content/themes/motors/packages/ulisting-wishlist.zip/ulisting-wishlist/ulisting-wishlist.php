<?php
/*
Plugin Name: uListing - Wishlist
Plugin URI: https://stylemixthemes.com
Description: uListing Wishlist WordPress Plugin.
Version: 1.0.8
Author: Stylemix Themes
Author URI: https://stylemixthemes.com
*/
if ( ! defined( 'ABSPATH' ) ) exit;

define( 'ULISTING_WISHLIST_VERSION', '1.0.8' );

define( 'ULISTING_WISHLIST_PATH', dirname( __FILE__ ) );
define( 'ULISTING_WISHLIST_FILE', __FILE__ );
define( 'ULISTING_WISHLIST_URL', plugins_url( '', __FILE__ ) );
require_once __DIR__ . '/includes/autoload.php';
register_activation_hook( __FILE__,  'uListing_wishlist_plugin_activation');
register_deactivation_hook( __FILE__, 'uListing_wishlist_plugin_deactivation');
register_uninstall_hook( __FILE__, 'uListing_wishlist_plugin_uninstall');
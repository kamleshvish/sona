<?php
function stm_layout_megamenu($layout)
{
}
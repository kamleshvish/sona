<?php

// Exit if accessed directly
defined('ABSPATH') || exit;

/**
 * WooCommerce Custom Order Admin
 *
 * @class RP_SUB_WC_Custom_Order_Admin
 * @package Subscriptio
 * @author RightPress
 */
abstract class RP_SUB_WC_Custom_Order_Admin extends RightPress_WC_Custom_Order_Admin
{

    /**
     * Constructor
     *
     * @access public
     * @return void
     */
    public function __construct()
    {

        // Call parent constructor
        parent::__construct();
    }





}

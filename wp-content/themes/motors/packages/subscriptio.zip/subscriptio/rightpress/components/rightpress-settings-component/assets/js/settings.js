/**
 * RightPress Settings Scripts
 */

jQuery(document).ready(function() {

    // TODO: Add something or remove file

});
